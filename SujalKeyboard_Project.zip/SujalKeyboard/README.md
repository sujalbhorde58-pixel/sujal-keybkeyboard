# Sujal Keyboard

Android keyboard prototype with a **✨ Short English** button.

Examples:
- kaha ho -> where u?
- kya kr rhe ho -> wyd?
- mujhe nhi pata -> idk
- mai aa raha hu -> omw
- abhi busy hu -> busy rn
- thanks -> ty

## Build
Open this folder in Android Studio, let Gradle sync, then Build > Build APK(s).

After installing, enable **Sujal Keyboard** in Android Settings > System > Keyboard > On-screen keyboard, then select it in Instagram.
