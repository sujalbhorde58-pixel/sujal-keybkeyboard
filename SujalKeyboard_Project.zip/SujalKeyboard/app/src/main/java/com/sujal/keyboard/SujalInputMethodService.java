package com.sujal.keyboard;

import android.inputmethodservice.InputMethodService;
import android.view.*;
import android.view.inputmethod.InputConnection;
import android.widget.*;
import java.util.*;

public class SujalInputMethodService extends InputMethodService {
    LinearLayout root; EditText input; TextView preview;
    final Map<String,String> map = new HashMap<>();
    @Override public View onCreateInputView() {
        load();
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        input = new EditText(this); input.setHint("Type Hinglish…"); input.setSingleLine(false);
        root.addView(input, new LinearLayout.LayoutParams(-1, 120));
        LinearLayout row = new LinearLayout(this);
        add(row,"✨ Short English", v -> {
            String out = translate(input.getText().toString().trim().toLowerCase());
            InputConnection ic=getCurrentInputConnection(); if(ic!=null && !out.isEmpty()) ic.commitText(out,1);
            input.setText(""); });
        add(row,"⌫", v -> { InputConnection ic=getCurrentInputConnection(); if(ic!=null) ic.deleteSurroundingText(1,0); });
        add(row,"↵", v -> { InputConnection ic=getCurrentInputConnection(); if(ic!=null) ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_ENTER)); });
        root.addView(row);
        return root;
    }
    void add(LinearLayout row,String s,View.OnClickListener l){ Button b=new Button(this); b.setText(s); b.setOnClickListener(l); row.addView(b,new LinearLayout.LayoutParams(0,70,1)); }
    String translate(String s){
        if(map.containsKey(s)) return map.get(s);
        if(s.equals("kaha ho")||s.equals("kidhar ho")||s.equals("kahan ho")) return "where u?";
        if(s.equals("kya kar rahe ho")||s.equals("kya kr rhe ho")||s.equals("kya kr rhi ho")) return "wyd?";
        if(s.equals("mujhe nahi pata")||s.equals("mujhe nhi pata")) return "idk";
        if(s.equals("main aa raha hu")||s.equals("mai aa raha hu")||s.equals("me aa raha hu")) return "omw";
        if(s.equals("abhi busy hu")||s.equals("mai busy hu")) return "busy rn";
        if(s.equals("baad me baat karte hai")||s.equals("bad me bat krte")) return "ttyl";
        return s;
    }
    void load(){
        map.put("hello","hey"); map.put("hi","hey"); map.put("thank you","ty");
        map.put("thanks","ty"); map.put("good night","gn"); map.put("good morning","gm");
        map.put("i don't know","idk"); map.put("i dont know","idk");
    }
}
